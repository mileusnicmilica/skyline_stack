# Evidence 003 — Skyline Stack

**Status**: Phase B baseline candidate; controlled change NOT STARTED  
**Date opened**: 2026-09-20  
**Evidence rule**: A command, output, screenshot, PASS/FAIL, diff, problem, or
human contribution appears as actual only after it exists and is verified.

## Initial Intent and Claim

Intent: produce a small original TypeScript/Canvas stacking game through the
specified Spec-Driven flow and leave reproducible evidence for one baseline
failure, one hypothesis, one controlled change, and the same evals afterward.

Current claim: the Core baseline candidate exists, deterministic tests,
typecheck, build, dev server, and a real Chromium interaction flow have run.
The immutable baseline archive, extracted-baseline rerun, and controlled change
are not yet claimed.

## Scope

In scope: single-player Core loop, Canvas/HUD, score/status, restart, exact
overlap boundary, one structured GameConfig with runtime validation, E1–E4,
baseline preservation, one hypothesis, one change, repeated evals, and pair
handoff.

Out of scope: all items listed in `docs/GAME_SPEC.md#out-of-scope`, including
backend, database, networking, deployment, multiplayer, persistence, extra game
modes, copied assets, and Session 004 features.

## Phase A Setup Evidence

| Command/check | Actual result |
| --- | --- |
| SHA-256 compare: attachment vs `prompts/prompt_v00.md` | Both 23,681 bytes; both `160D43B5BF6B7C17F4612F8A310EDEA0587A4750682F1ABC86A529513D626E3C` |
| `python -m pip install --user specify-cli==1.0.8` | Exit 0; `specify-cli-1.0.8` and dependencies installed; user Scripts path warning reported |
| Explicit `specify.exe version` | Exit 0; CLI 1.0.8, Python 3.11.7, Windows AMD64 |
| `specify init --here --force --non-interactive --integration codex --integration-options="--skills" --script ps --ignore-agent-tools` | Exit 0; project ready; Codex skills and PowerShell infrastructure created |
| Check for `.git` after initialization | `.git ABSENT` |
| Spec Kit sequence | constitution, specify, clarify, plan, tasks completed; implement NOT RUN |

The full pip output is available in the AI session transcript; it contained no
project secret. After Phase A, the human pair created and pushed
`phase-b/skyline-stack-core` to `origin`; the agent did not create or modify the
remote. The ZIP evidence method remains in force because it is the locked
baseline method.

## Baseline Identity

- Planned location: `artifacts/session-003/baseline.zip`
- Planned visual evidence: `artifacts/session-003/baseline.png`
- Archive status: NOT RUN
- Read-only status: NOT RUN
- SHA-256: TBD
- Exclusions: TBD; intended to exclude dependency/build caches and the archive
  destination itself
- Re-extraction verification: NOT RUN

This is a proposed verifiable snapshot method because no local Git repository
was approved or initialized. The location is not evidence that the files exist.

## Locked Build Prompt and Context

- Build prompt: `docs/BUILD_PROMPT_V1.md` v1.0 lock candidate
- Gameplay/scope: `docs/GAME_SPEC.md` v1.0 lock candidate
- Context manifest: `docs/CONTEXT_MANIFEST.md`
- Spec Kit feature directory: `specs/001-skyline-stack-core/`
- Eval expectations: `docs/EVALS.md`
- Human approval to lock/start Phase B: supplied in the 2026-09-20 handoff
- Prompt SHA-256: `160D43B5BF6B7C17F4612F8A310EDEA0587A4750682F1ABC86A529513D626E3C`
- Build prompt SHA-256: current CRLF working-tree bytes are
  `CF2D72431A69E4BFC14278C9CAF8534A578A989E1D3107A98603C96563BE3699`;
  LF-normalized content is the handed-off
  `9D306ED3059C8C35D4071323F6633C89DA7505C7EEDE0BD7215DDDCD7AD88066`

## Application Commands and Actual Outputs

| Purpose | Command | Baseline result | Post-change result |
| --- | --- | --- | --- |
| Install | `$env:NODE_OPTIONS='--use-system-ca'; npm.cmd install --save-dev --save-exact vite typescript vitest` | Exit 0; added 39 packages; audited 40; 0 vulnerabilities; pinned TypeScript 7.0.2, Vite 8.3.0, Vitest 5.0.1 | NOT RUN |
| Typecheck | `npm.cmd run typecheck` | Exit 0; `tsc --noEmit` produced no errors | NOT RUN |
| Test | `npm.cmd test` | Exit 0; 5 files and 37 tests passed | NOT RUN |
| Build | `npm.cmd run build` | Exit 0; Vite 8.3.0 transformed 11 modules and produced `dist/` in 251 ms | NOT RUN |
| Run | `npm.cmd run dev -- --host 127.0.0.1` | Server remained running; Vite ready in 311 ms at `http://127.0.0.1:5173/` | NOT RUN |
| Browser smoke | `npm.cmd run smoke -- http://127.0.0.1:5173/ artifacts/session-003/baseline.png` | Exit 0 after harness cleanup stabilization; Ready 0 → Playing 1 → Game Over 1 → Ready 0; no JS exceptions; one 404 browser log entry | NOT RUN |

The first smoke invocation completed the interaction flow and screenshot but
exited 1 because the evidence helper deleted its temporary Chromium profile
before Chrome released a lock; the same run also reported the 404 log entry.
Only the helper cleanup was stabilized before the recorded rerun. No gameplay
or layout code was changed.

## Screenshot or Equivalent Visual Proof

- Baseline proof: `artifacts/session-003/baseline.png` exists; captured after a
  successful placement with score 1 and Playing status
- Post-change proof, if relevant to E4: NOT RUN
- Sensitive-data review: screenshot inspected; no secret, token, private URL,
  environment value, or private payload is visible
- Baseline visual observation: at the 1280×1002 browser viewport the 480×640
  canvas is styled to 826×1101.328 px (`top=130.266`, `bottom=1231.594`), so
  the lower play area and footer controls are below the initial viewport

## Initial Test Status

The first US1 test run exited 1 with four missing-module suites, as expected
before implementation. The US2 pre-implementation run had 14 passes and two
missing restart-function failures. The US3 pre-implementation run had 16
passes and 21 missing-validator failures. The complete baseline candidate now
passes 37/37 tests in five files.

## Baseline Eval Table

| ID | Locked expectation source | Actual baseline result | Status | Evidence |
| --- | --- | --- | --- | --- |
| E1 | `docs/EVALS.md` | NOT RUN | NOT RUN | NOT RUN |
| E2 | `docs/EVALS.md` | NOT RUN | NOT RUN | NOT RUN |
| E3 | `docs/EVALS.md` | NOT RUN | NOT RUN | NOT RUN |
| E4 | Scenario TBD until real repeatable baseline problem | NOT RUN | NOT RUN | NOT RUN |

## Selected Problem and Controlled Change

```text
Tvrdnja: TBD
Signal: NOT RUN
Hipoteza: TBD
Najmanja promena: TBD
Provera: NOT RUN
Rezultat: NOT RUN
Ograničenje: TBD
```

Planned diff: TBD; must be shown before the edit.  
Actual diff: NOT RUN; must be shown after exactly one targeted edit.

## Same Eval Set After Change

| ID | Identical scenario confirmed? | Actual post-change result | Status | Evidence |
| --- | --- | --- | --- | --- |
| E1 | NOT RUN | NOT RUN | NOT RUN | NOT RUN |
| E2 | NOT RUN | NOT RUN | NOT RUN | NOT RUN |
| E3 | NOT RUN | NOT RUN | NOT RUN | NOT RUN |
| E4 | NOT RUN | NOT RUN | NOT RUN | NOT RUN |

## Final Result and Known Limitation

- Final result: NOT RUN
- Known limitation supported by evidence: TBD
- Session 003 completion claim: NOT MADE

## Pair Work and Role Swaps

Human names and actual contributions were not supplied. The following are
planned checkpoints, not completed contributions:

| Block / swap point | Driver | Observer | Driver action | Observer check | Actual result |
| --- | --- | --- | --- | --- | --- |
| First specification draft → before corrections | TBD | TBD | TBD | Review scope and acceptance expectations | TBD |
| First technical plan → before task list | TBD | TBD | TBD | Review tool necessity and structure | TBD |
| First baseline run or precise blocker | TBD | TBD | TBD | Review command output and visible state | NOT RUN |
| Eval expectations recorded → before actual results | TBD | TBD | TBD | Confirm expectations precede execution | NOT RUN |
| Targeted change → before repeated eval | TBD | TBD | TBD | Review planned/actual diff and unchanged evals | NOT RUN |

Do not replace any TBD with an inferred name or action. During Phase B record
who actually drove, who observed, what each did, when roles swapped, and the
verified result.

## Reproduction Instructions

Phase A review:

1. Verify `prompts/prompt_v00.md` hash against the value above.
2. Review constitution, spec, plan, tasks, GAME_SPEC, BUILD_PROMPT, manifest,
   EVALS, this template, and AI log.
3. Confirm that `README.md`, `package.json`, `src/`, and `tests/` are absent.
4. Approve or request changes; do not run implementation from this template.

Phase B reproduction: TBD until actual commands, archive hash, extracted path,
browser URL, test output, and E4 steps exist.

## Session 003 Definition of Done Audit

| Requirement | Phase A status | Evidence / blocker |
| --- | --- | --- |
| Original prompt preserved | VERIFIED | matching byte count and SHA-256 above |
| Spec Kit initialized or blocker documented | VERIFIED | CLI/init exit 0; `.git` absent |
| GAME_SPEC has small scope and verifiable DoD | VERIFIED FOR REVIEW | `docs/GAME_SPEC.md` |
| BUILD_PROMPT exists before implementation | VERIFIED FOR REVIEW | `docs/BUILD_PROMPT_V1.md`; implementation NOT RUN |
| CONTEXT_MANIFEST lists included/excluded sources | VERIFIED FOR REVIEW | `docs/CONTEXT_MANIFEST.md` |
| Baseline preserved and not overwritten | NOT RUN | Phase B |
| Real run command and output | NOT RUN | Phase B |
| Initial test status | VERIFIED AS NOT RUN | no project tests exist in Phase A |
| GameConfig type, valid and invalid examples | DOCUMENTED ONLY | implementation NOT RUN |
| Actual runtime validation and fallback | NOT RUN | Phase B |
| At least four eval cases | DOCUMENTED ONLY | E1–E3 locked; E4 scenario TBD |
| Expectations recorded before execution | VERIFIED FOR REVIEW | all results NOT RUN |
| At least one real baseline failure | NOT RUN | E4 TBD |
| Same eval set before and after | NOT RUN | Phase B |
| Exactly one hypothesis | NOT RUN | TBD |
| Exactly one controlled change | NOT RUN | Phase B |
| Actual evidence and reproducible verification | NOT RUN | Phase B |
| Both pair contributions and role swaps | TBD | human data not supplied |
| AI usage log | VERIFIED FOR REVIEW | `docs/AI_USAGE_LOG.md` |
| No secrets in code/docs | VERIFIED FOR PHASE A | obvious private-key/API-token pattern scan returned NONE; repeat in Phase B |
| No multiplayer/backend/database/deployment | VERIFIED FOR PHASE A | no application files exist |
| No Session 004 features | VERIFIED FOR PHASE A | no application files exist |
